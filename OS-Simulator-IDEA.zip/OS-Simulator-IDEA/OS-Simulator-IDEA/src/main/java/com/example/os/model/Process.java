package com.example.os.model;

public class Process {
    private int pid;
    private String name;
    private int time;
    private int memory;
    private int priority;
    private String state;

    public int getPid() { return pid; }
    public void setPid(int pid) { this.pid = pid; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public int getTime() { return time; }
    public void setTime(int time) { this.time = time; }
    public int getMemory() { return memory; }
    public void setMemory(int memory) { this.memory = memory; }
    public int getPriority() { return priority; }
    public void setPriority(int priority) { this.priority = priority; }
    public String getState() { return state; }
    public void setState(String state) { this.state = state; }
}
