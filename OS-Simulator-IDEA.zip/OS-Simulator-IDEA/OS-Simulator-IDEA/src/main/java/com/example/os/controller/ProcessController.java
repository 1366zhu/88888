package com.example.os.controller;

import com.example.os.model.Process;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/process")
@CrossOrigin
public class ProcessController {

    private final List<Process> processes = new ArrayList<>();
    private int pidCounter = 1;

    @PostMapping("/create")
    public List<Process> create(@RequestBody Process p) {
        p.setPid(pidCounter++);
        p.setState("READY");
        processes.add(p);
        return processes;
    }

    @GetMapping("/list")
    public List<Process> list() {
        return processes;
    }

    @DeleteMapping("/terminate/{pid}")
    public void terminate(@PathVariable int pid) {
        processes.removeIf(p -> p.getPid() == pid);
    }
}
