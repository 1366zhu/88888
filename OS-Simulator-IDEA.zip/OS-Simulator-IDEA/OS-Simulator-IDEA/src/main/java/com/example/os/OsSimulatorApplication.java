package com.example.os;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OsSimulatorApplication {
    public static void main(String[] args) {
        SpringApplication.run(OsSimulatorApplication.class, args);
    }
}
