package com.example.os.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/memory")
@CrossOrigin
public class MemoryController {

    private int used = 0;
    private final int TOTAL = 1024;

    @PostMapping("/allocate")
    public String allocate(@RequestParam int size) {
        if (used + size > TOTAL) {
            return "内存不足";
        }
        used += size;
        return "分配成功";
    }

    @GetMapping("/status")
    public int status() {
        return used;
    }
}
